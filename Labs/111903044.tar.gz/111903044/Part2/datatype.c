#include <stdio.h>
#include <ints.h>

int main()
{
    printf("Size of i8_t : %lu\n", sizeof(i8_t));
    printf("Size of i16_t : %lu\n", sizeof(i16_t));
    printf("Size of i32_t : %lu\n", sizeof(i32_t));
    printf("Size of i64_t : %lu\n", sizeof(i64_t));
    printf("Size of u8_t : %lu\n", sizeof(u8_t));
    printf("Size of u16_t : %lu\n", sizeof(u16_t));
    printf("Size of u32_t : %lu\n", sizeof(u32_t));
    printf("Size of u64_t : %lu\n", sizeof(u64_t));
    return 0;
}