#ifndef ADDITION_H_INCLUDED
#define ADDITION_H_INCLUDED

int add(int a, int b);

#endif