int multi(int a, int b)
{
    return a * b;
}
