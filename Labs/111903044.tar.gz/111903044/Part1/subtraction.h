#ifndef SUBTRACTION_H_INCLUDED
#define SUBTRACTION_H_INCLUDED

int sub(int a, int b);

#endif