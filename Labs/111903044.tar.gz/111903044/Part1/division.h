#ifndef DIVISION_H_INCLUDED
#define DIVISION_H_INCLUDED

int div(int a, int b);

#endif