#ifndef MODULE1_H_INCLUDED
#define MODULE1_H_INCLUDED

int fact(int num);
void subtract(int num, int num1);
#endif // MODULE1_H_INCLUDED
