declare -A hm

generate_make_file() {
    rm -f Makefile
    echo "all: a.out" >> Makefile
    str3=""
    for key in ${!hm[@]}
    do
        str="$key.o: "
        str3+="$key.o "
        str1="$key.c "
        IFS=' '
        read -ra temp <<< "${hm[$key]}"
        for val in ${temp[@]}
        do 
            str1+="$val "
        done
        str+=$str1
        echo $str
        echo -e "a.out: $str3" >> Makefile
        echo -e "\tgcc -Wall $str3" >> Makefile
        echo -n $str >> Makefile
        echo >> Makefile
        echo -e "\tgcc -Wall -c $str1" >> Makefile
    done
}

read_cscope_func() {
    arr1=$1
    str1=$(cscope -L3 ${arr1[0]})
    if [ ${#str1} -gt 0 ];then
        IFS=$'\n'
        read -rd '' -a y <<<"$str1"
        for val in "${y[@]}";
        do
            IFS=' '
            read -ra line1 <<< "$val"
            
            IFS='.'
            read -ra temp <<< "${line1[0]}"
            if [ ${#hm[$temp]} -eq 0 ];then
                hm[$temp]=""
            fi
        done
        for key in ${!hm[@]}
        do
            hm[$key]+=$2
            hm[$key]+=" "
        done
    fi
}

read_tags_line() {
    line=$1
    c=${line:0:1}
    if [ $c != "!" ]; then
        IFS=$'\t'
        read -ra arr <<< "$line"
        if [ `echo ${arr[1]} | grep -c ".c" ` -gt 0 ];then
            read_cscope_func ${arr[0]} ${arr[1]}
        fi
    fi
}

process () {
    vl=`echo $1 | grep  '#include "[^"]*"' -o`
    echo "${vl}"

}

get_header_files() {
    for FILE in *; do 
    IFS='.'
    read -ra temp <<< $FILE
    if [ "${temp[1]}" = "c" ]
    then 
        process "$(<$FILE)" ${temp[0]}
    fi
    done
}

ctags -R .
file="tags"
while read -r line; do
    read_tags_line "$line"
done <$file

for key in ${!hm[@]}
do
    echo "$key: ${hm[$key]}"
done
generate_make_file
# get_header_files