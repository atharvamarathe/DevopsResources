#include <stdio.h>
#include <stdlib.h>
#include "module1.h"
#include "module2.h"
#include <limits.h>



//the logging code ends here
int main()
{
	int a,b;
	scanf("%d",&a);
	if(a < 0 ) {
		b = fact(a);
	}
	else {
		b = fact(a);
	}

	
	int ans;
	ans = mul(a,b);
	if(ans == INT_MIN) {
		return 1;
	}
	
	
	return 0;
}
