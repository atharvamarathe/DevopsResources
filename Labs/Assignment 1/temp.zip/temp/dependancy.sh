process () {
    vl=`echo $1 | grep  '#include "[^"]*"' -o`
    echo "${vl}"

}
for FILE in *; do 
if [ `echo $FILE | grep -c ".c" ` -gt 0 ]
then 
    value=$(<$FILE)
    process "$(<$FILE)"
fi

done