#include <stdio.h>
#include <ints.h>

int main()
{
   u32_t a = 10;
   u32_t b = 20;
   u32_t c = a+b;
    return 0;
}