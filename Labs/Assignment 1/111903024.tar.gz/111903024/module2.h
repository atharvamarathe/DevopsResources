#ifndef MODULE2_H_INCLUDED
#define MODULE2_H_INCLUDED

int mul(int num, int num1);

#endif // MODULE2_H_INCLUDED
